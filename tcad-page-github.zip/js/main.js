import { createIcons, icons } from 'https://cdn.jsdelivr.net/npm/lucide@0.468.0/+esm';
import { software, apks, products, hobbies, profile } from './data.js';

const $ = (s) => document.querySelector(s);
const refreshIcons = () => createIcons({ icons });

/* ---------- Faixa animada ---------- */
const words = ['Audiovisual', 'Empreendedorismo', 'Engenharia', 'Software', 'APKs', 'Roupas', 'Serviços', 'Hobbies'];
const row = words.map(w => `<span class="flex items-center gap-2 whitespace-nowrap"><i data-lucide="sparkle" class="w-3.5 h-3.5 text-mauve"></i>${w}</span>`).join('');
$('#marquee').innerHTML = row + row;

/* ---------- Software ---------- */
$('#swList').innerHTML = software.map((s, i) => `
  <div class="sw-card rounded-2xl p-4 flex items-center gap-4">
    <div class="w-11 h-11 rounded-xl bg-pink/15 flex items-center justify-center shrink-0"><i data-lucide="${s.icon}" class="w-5 h-5 text-pink"></i></div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2 flex-wrap">
        <p class="text-[14px] text-cream font-medium truncate">${s.name}</p>
        <span class="text-[10px] text-pink border border-pink/30 rounded px-1.5">${s.version}</span>
      </div>
      <p class="text-[11px] text-cream/45 mt-0.5 truncate">${s.os} · ${s.size} · ${s.tag}</p>
    </div>
    <button data-kind="sw" data-i="${i}" class="dl-btn shrink-0 h-9 px-3 rounded-lg bg-cream text-ink text-[12px] font-medium flex items-center gap-1.5 hover:bg-pink transition-colors">
      <i data-lucide="download" class="w-3.5 h-3.5"></i><span class="hidden sm:inline">Baixar</span>
    </button>
  </div>`).join('');

/* ---------- APKs ---------- */
$('#apkList').innerHTML = apks.map((a, i) => `
  <div class="apk-card rounded-2xl p-4">
    <div class="flex items-center gap-3">
      <div class="app-icon w-12 h-12 flex items-center justify-center shrink-0" style="background:${a.color}"><i data-lucide="${a.icon}" class="w-5 h-5 text-cream"></i></div>
      <div class="min-w-0">
        <p class="text-[14px] font-medium truncate">${a.name}</p>
        <p class="text-[11px] text-muted">${a.category}</p>
      </div>
    </div>
    <div class="flex items-center justify-between mt-4 text-[11px] text-muted">
      <span class="flex items-center gap-1"><i data-lucide="star" class="w-3 h-3 text-mauve fill-current"></i>${a.rating}</span>
      <span>v${a.version}</span><span>${a.size}</span>
    </div>
    <button data-kind="apk" data-i="${i}" class="dl-btn mt-3 w-full h-9 rounded-full bg-ink text-cream text-[12px] font-medium flex items-center justify-center gap-1.5 hover:bg-mauve transition-colors">
      <i data-lucide="arrow-down-to-line" class="w-3.5 h-3.5"></i> Instalar APK
    </button>
  </div>`).join('');

/* ---------- Vitrine ---------- */
const statusMap = {
  'em-breve': { t: 'Em breve', c: 'bg-cream text-ink' },
  'pre-venda': { t: 'Pré-venda', c: 'bg-mauve text-cream' },
  'disponivel': { t: 'Disponível', c: 'bg-ink text-cream' },
};
function renderShop(f = 'all') {
  $('#shopGrid').innerHTML = products.filter(p => f === 'all' || p.type === f).map(p => {
    const st = statusMap[p.status] || statusMap['em-breve'];
    return `
    <article class="shop-card group rounded-3xl bg-blush overflow-hidden flex flex-col">
      <div class="relative aspect-square overflow-hidden">
        <img src="${p.img}" alt="${p.name}" class="shop-img toy-blend w-full h-full object-cover">
        <span class="absolute top-3 left-3 text-[10px] uppercase tracking-[.15em] rounded-full px-2.5 py-1 ${st.c}">${st.t}</span>
        <button class="notify-btn absolute top-3 right-3 w-8 h-8 rounded-full glass flex items-center justify-center hover:bg-white" aria-label="Avisar"><i data-lucide="heart" class="w-4 h-4 text-mauve"></i></button>
      </div>
      <div class="p-4 flex items-end justify-between gap-2">
        <div class="min-w-0">
          <p class="text-[10px] uppercase tracking-[.15em] text-muted">${p.note}</p>
          <h3 class="font-serif text-xl leading-tight truncate">${p.name}</h3>
        </div>
        <p class="text-[13px] font-medium whitespace-nowrap">${p.price}</p>
      </div>
    </article>`;
  }).join('');
  refreshIcons();
}

/* ---------- Hobbies ---------- */
function renderHobbies(f = 'all') {
  $('#hobGrid').innerHTML = hobbies.filter(h => f === 'all' || h.type === f).map(h => {
    if (h.type === 'video') {
      const media = h.youtube
        ? `<iframe class="w-full aspect-video" src="https://www.youtube.com/embed/${h.youtube}" title="${h.title}" allowfullscreen loading="lazy"></iframe>`
        : h.src
          ? `<video class="w-full" src="${h.src}" controls playsinline preload="metadata"></video>`
          : `<div class="aspect-video bg-ink flex flex-col items-center justify-center gap-3 text-cream">
               <div class="w-14 h-14 rounded-full bg-pink flex items-center justify-center"><i data-lucide="play" class="w-6 h-6 text-ink fill-current"></i></div>
               <span class="text-[11px] tracking-[.2em] uppercase text-cream/50">Vídeo em breve</span>
             </div>`;
      return `<div class="hob-item rounded-3xl overflow-hidden bg-ink">${media}
        <div class="p-4 flex items-center justify-between text-cream"><p class="font-serif text-xl">${h.title}</p><span class="text-[10px] uppercase tracking-[.15em] text-cream/50 flex items-center gap-1"><i data-lucide="video" class="w-3 h-3"></i>${h.place}</span></div></div>`;
    }
    return `<div class="hob-item relative rounded-3xl overflow-hidden bg-cream group">
      <img src="${h.src}" alt="${h.title}" loading="lazy" class="w-full ${h.tall ? 'aspect-[3/4]' : 'aspect-square'} object-cover">
      <div class="absolute inset-x-3 bottom-3 glass rounded-2xl px-4 py-3 flex items-center justify-between">
        <p class="font-serif text-lg">${h.title}</p>
        <span class="text-[10px] uppercase tracking-[.15em] text-muted flex items-center gap-1"><i data-lucide="image" class="w-3 h-3"></i>${h.place}</span>
      </div></div>`;
  }).join('');
  refreshIcons();
}

/* ---------- Abas ---------- */
function bindTabs(sel, fn) {
  $(sel).addEventListener('click', e => {
    const b = e.target.closest('button[data-f]');
    if (!b) return;
    $(sel).querySelectorAll('button').forEach(x => x.classList.remove('tab-active'));
    b.classList.add('tab-active');
    fn(b.dataset.f);
  });
}
bindTabs('#shopTabs', renderShop);
bindTabs('#hobTabs', renderHobbies);

/* ---------- Toast ---------- */
let toastT;
function toast(msg) {
  $('#toastMsg').textContent = msg;
  $('#toast').classList.remove('hide');
  clearTimeout(toastT);
  toastT = setTimeout(() => $('#toast').classList.add('hide'), 2600);
}

/* ---------- Animação de download ---------- */
const modal = $('#dlModal');
const ring = $('#dlRing');
const CIRC = 339.3;
let dlTimer = null;

async function fileExists(path) {
  try { const r = await fetch(path, { method: 'HEAD' }); return r.ok; } catch { return false; }
}

function closeModal() {
  clearInterval(dlTimer);
  modal.classList.add('hidden-m');
}

async function startDownload(kind, item) {
  $('#dlKind').textContent = kind === 'apk' ? 'APK · Android' : 'Software · ' + item.os;
  $('#dlName').textContent = item.name;
  $('#dlToy').src = kind === 'apk' ? 'assets/img/toys/toy-phone.png' : 'assets/img/toys/toy-rocket.png';
  $('#dlResult').textContent = '';
  $('#dlPct').textContent = '0';
  ring.style.strokeDashoffset = CIRC;
  const steps = [...document.querySelectorAll('#dlSteps .step')];
  steps.forEach(s => s.classList.remove('on', 'ok'));
  modal.classList.remove('hidden-m');

  const existsP = fileExists(item.file);
  let p = 0;
  clearInterval(dlTimer);
  dlTimer = setInterval(async () => {
    p = Math.min(100, p + Math.random() * 6 + 2);
    ring.style.strokeDashoffset = CIRC * (1 - p / 100);
    $('#dlPct').textContent = Math.floor(p);
    steps.forEach((s, i) => {
      const th = (i + 1) * 33;
      s.classList.toggle('on', p >= th - 33);
      s.classList.toggle('ok', p >= th);
    });
    if (p >= 100) {
      clearInterval(dlTimer);
      const ok = await existsP;
      if (ok) {
        const a = document.createElement('a');
        a.href = item.file; a.download = item.file.split('/').pop();
        document.body.appendChild(a); a.click(); a.remove();
        $('#dlResult').textContent = 'Download iniciado. Aproveite!';
        setTimeout(closeModal, 1600);
      } else {
        $('#dlResult').innerHTML = 'Este arquivo chega em breve. Siga <a class="text-pink underline" target="_blank" rel="noopener" href="https://instagram.com/' + profile.instagram + '">@' + profile.instagram + '</a> para saber.';
      }
    }
  }, 90);
}

document.addEventListener('click', e => {
  const b = e.target.closest('.dl-btn');
  if (b) {
    const list = b.dataset.kind === 'apk' ? apks : software;
    startDownload(b.dataset.kind, list[+b.dataset.i]);
    return;
  }
  if (e.target.closest('.notify-btn')) {
    document.querySelector('#notifyForm input').focus();
    toast('Deixe seu e-mail para ser avisado');
  }
});
$('#dlClose').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

/* ---------- Formulários / contato ---------- */
$('#notifyForm').addEventListener('submit', e => {
  e.preventDefault();
  const email = e.target.querySelector('input').value;
  window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent('Quero ser avisado do lançamento tCad')}&body=${encodeURIComponent('Meu e-mail: ' + email)}`;
  e.target.reset();
  toast('Obrigado! Você será avisado.');
});
$('#copyEmail').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(profile.email); toast('E-mail copiado'); }
  catch { toast(profile.email); }
});

/* ---------- Menu mobile ---------- */
$('#menuBtn').addEventListener('click', () => $('#mobileMenu').classList.toggle('hidden'));
document.querySelectorAll('#mobileMenu a').forEach(a => a.addEventListener('click', () => $('#mobileMenu').classList.add('hidden')));

$('#year').textContent = new Date().getFullYear();

/* ---------- Toys 3D: parallax com o mouse ---------- */
const toys = [...document.querySelectorAll('.toy[data-depth]')];
const canHover = window.matchMedia('(hover:hover)').matches;
if (canHover) {
  window.addEventListener('mousemove', e => {
    const x = (e.clientX / innerWidth - 0.5);
    const y = (e.clientY / innerHeight - 0.5);
    toys.forEach(t => {
      const d = +t.dataset.depth;
      t.style.transform = `translate(${x * d}px, ${y * d}px) rotateY(${x * 10}deg) rotateX(${-y * 10}deg)`;
    });
  });
}

/* ---------- Init ---------- */
renderShop();
renderHobbies();
refreshIcons();

const io = new IntersectionObserver(entries => {
  entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));
