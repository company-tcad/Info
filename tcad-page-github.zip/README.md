# tCad page — Cadesuh

Landing page estática (HTML + Tailwind CDN + JS). Sem build.

Publicação: GitHub Pages → Settings → Pages → Branch `main` / pasta `/ (root)`.

Edite textos, produtos e downloads em `js/data.js`. Coloque os arquivos de download em `downloads/`.
