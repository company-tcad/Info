/* =========================================================
   tCad page — CONTEÚDO EDITÁVEL
   Edite apenas este arquivo para trocar textos, produtos,
   softwares, APKs e fotos/vídeos dos hobbies.
   ========================================================= */

export const profile = {
  name: 'Cadesuh',
  brand: 'tCad',
  email: 'tcadbusiness@gmail.com',
  instagram: 'cadesuh.official',
};

/* ---------- SOFTWARES (PC / Web) ----------
   file: coloque o arquivo em /downloads e informe o caminho.
   Se o arquivo ainda não existir, o site mostra "em breve". */
export const software = [
  { name: 'tCad Toolkit', version: 'v0.3.1', os: 'Windows', size: '18 MB', tag: 'Utilitário', icon: 'wrench',
    desc: 'Atalhos e ferramentas para agilizar projetos de engenharia.', file: 'downloads/tcad-toolkit.zip' },
  { name: 'FrameCut', version: 'v1.0.0', os: 'Windows · macOS', size: '42 MB', tag: 'Vídeo', icon: 'scissors',
    desc: 'Corte e organize clipes rapidamente para seus vídeos.', file: 'downloads/framecut.zip' },
  { name: 'CalcPro Eng', version: 'beta', os: 'Web', size: '—', tag: 'Engenharia', icon: 'calculator',
    desc: 'Calculadoras para elétrica, estruturas e conversões.', file: 'downloads/calcpro-eng.zip' },
];

/* ---------- APKs (Android) ---------- */
export const apks = [
  { name: 'tCad Notes', version: '1.2', size: '9 MB', rating: '4.8', category: 'Produtividade', color: '#a8606d', icon: 'notebook-pen',
    file: 'downloads/tcad-notes.apk' },
  { name: 'ShotList', version: '0.9', size: '14 MB', rating: '4.6', category: 'Audiovisual', color: '#1f1a1a', icon: 'clapperboard',
    file: 'downloads/shotlist.apk' },
  { name: 'Circuit Lab', version: '2.0', size: '21 MB', rating: '4.9', category: 'Engenharia', color: '#c98794', icon: 'cpu',
    file: 'downloads/circuit-lab.apk' },
  { name: 'Hustle Tracker', version: '1.0', size: '7 MB', rating: '4.7', category: 'Negócios', color: '#6f4a52', icon: 'trending-up',
    file: 'downloads/hustle-tracker.apk' },
];

/* ---------- VITRINE (produtos, roupas, serviços) ----------
   status: 'em-breve' | 'pre-venda' | 'disponivel' */
export const products = [
  { name: 'Hoodie tCad Studio', type: 'roupas', price: 'R$ 189', status: 'em-breve', img: 'assets/img/toys/toy-hoodie.png', note: 'Drop 01' },
  { name: 'Mentoria de Edição', type: 'servicos', price: 'R$ 97', status: 'pre-venda', img: 'assets/img/toys/toy-camera.png', note: '1h ao vivo' },
  { name: 'Kit de Apps Pro', type: 'digitais', price: 'R$ 29', status: 'em-breve', img: 'assets/img/toys/toy-phone.png', note: 'Licença vitalícia' },
  { name: 'Consultoria de Projeto', type: 'servicos', price: 'Sob consulta', status: 'em-breve', img: 'assets/img/toys/toy-rocket.png', note: 'Engenharia + negócio' },
];

/* ---------- HOBBIES (fotos e vídeos) ----------
   type: 'foto' usa src de imagem (coloque em assets/img/hobbies)
   type: 'video' aceita youtube (ID do vídeo) ou src de .mp4 */
export const hobbies = [
  { type: 'foto', title: 'Setup de gravação', place: 'Estúdio', src: 'assets/img/hero.png', tall: true },
  { type: 'video', title: 'Primeiro vlog', place: 'Em breve', youtube: '' },
  { type: 'foto', title: 'Câmera favorita', place: 'Coleção', src: 'assets/img/toys/toy-camera.png' },
  { type: 'foto', title: 'Projetos & protótipos', place: 'Bancada', src: 'assets/img/toys/toy-rocket.png' },
  { type: 'video', title: 'Bastidores do drop', place: 'Em breve', youtube: '' },
  { type: 'foto', title: 'Estilo & moda', place: 'Lookbook', src: 'assets/img/toys/toy-hoodie.png', tall: true },
];
